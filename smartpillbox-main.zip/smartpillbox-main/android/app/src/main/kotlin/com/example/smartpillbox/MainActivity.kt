package com.example.smartpillbox

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
